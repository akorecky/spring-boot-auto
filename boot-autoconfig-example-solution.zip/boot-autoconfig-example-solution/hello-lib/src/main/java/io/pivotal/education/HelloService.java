package io.pivotal.education;

public interface HelloService {
  void greet();
}
